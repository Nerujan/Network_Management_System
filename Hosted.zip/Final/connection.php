<?php 

$hostname = "sql100.infinityfree.com";
$username = "if0_34959774";
$password = "90VFnFdxA2";
$dbname = "if0_34959774_network";

$con = mysqli_connect($hostname,$username,$password,$dbname);//procedural style
//$con= new mysqli($hostname,$username,$password,$dbname); //ovject oriented style

if(!$con){
    die("Connection failed : ".mysqli_connect_error());//procedural style
	//die("Connection failed : ".$con->connect_error);//object oriented style
}

?>